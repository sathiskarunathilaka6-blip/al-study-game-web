# AL Study Game — Web Final

Mobile-first gamified A/L study web app for Accounting, Business Studies and Economics.

## Included
- Premium futuristic animated UI
- Scroll reveal + text animations + micro-interactions
- Home hub, subject worlds, chapter map, mission flow
- Sinhala study lessons and original exam-style questions
- Lesson → Recall → Practice → Past Paper Practice → Predicted → Mission Complete
- XP, levels, combo multiplier, streaks, daily quests
- Lives, daily hint limit (5 base + shop bonus), Double XP, Freeze
- Coins + Rewards Shop
- Daily chest state + Study Hero evolution data model
- Chapter Boss Battles
- Progress Map, statistics, achievements
- AI Tutor interface (secure-backend-ready; no browser API key)
- Smart revision entry point + weak-topic tracking
- LocalStorage save + JSON backup/restore
- Stable mission IDs for future content updates
- Separate `content.json` so lessons/questions can be updated without rewriting the game engine
- PWA/service worker shell for GitHub Pages

## Content scope
The initial content is based on the study materials already supplied for this project. It is an initial playable content pack, not a claim that the entire A/L syllabus is included.

## GitHub Pages
Upload the files to a public GitHub repository and enable Pages from the repository's Pages settings. No server/database/login is required for this version.

## Future architecture
Authentication, cloud sync, admin panel and a secure AI backend can be added later without changing the core mission IDs/content structure.
